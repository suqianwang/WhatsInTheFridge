import json
import os
import json
import sqlite3
import random
import datetime
random.seed(1)



def id2rcp(ids):
    """
    Transcribe recipe ids to recipe names, along with other optional information.
    :param ids: list of ints. List of recipe ids.
    :param return_info: boolean. Return other misc information or not.
    :return: dict/ json.
     Keys are 'rcp_names'
        'rcp_idxs'
        'minutes'
        'tags'
        'nutritions'
        'n_steps'
        'steps'
        'descriptions'
        'ingredients'
        'n_ingredients'
    """
    
    raw_rcps_db = sqlite3.connect('/mnt/witf_lambda_efs/raw_rcps.db')
    raw_rcps_c = raw_rcps_db.cursor()
    rets = {
        'rcp_names': [],
        'rcp_idxs': [],
        'minutes': [],
        'tags': [],
        'nutritions': [],
        'n_steps': [],
        'steps': [],
        'descriptions': [],
        'ingredients': [],
        'n_ingredients': []
    }
    for id_ in ids:
        raw_rcps_c.execute('''Select * from raw_rcps where rcp_idx={} Limit 1'''.format(id_))
        rcp_idx, name, minutes, tags, nutrition, n_steps, steps, description, ingredients, n_ingredients = raw_rcps_c.fetchone()
        rets['rcp_names'].append(name)
        rets['rcp_idxs'].append(rcp_idx)
        rets['minutes'].append(minutes)
        rets['tags'].append(tags)
        rets['nutritions'].append(nutrition)
        rets['n_steps'].append(n_steps)
        rets['steps'].append(steps)
        rets['descriptions'].append(description)
        rets['ingredients'].append(ingredients)
        rets['n_ingredients'].append(n_ingredients)

    raw_rcps_db.close()

    return rets


def lambda_handler(event, context):
    
    """
    Generate a list of recipe id recommendations.
    if n >= len(last recoms) return n recommendations,
    else return len(last_recoms) recommendations.
    :param inputs: dict/ json. Keys are 'last_recoms', 'user_id', 'recom_amount'
    :return: list of ints. List of recommending recipe ids.
    """
    # "recom_hist": recom_hist,
    #     "user_id": user_id,
    #     "recom_amount": n,
    
    print('## ENVIRONMENT VARIABLES')
    print(os.environ)
    print('## EVENT')
    print(event)
    print("step 1", datetime.datetime.now())
    recom_hist = event.get('recom_hist')
    liked_recoms = event.get('liked_recoms')
    user_id = event.get('user_id')
    n = event.get('recom_amount')
    
    rcp_sims_db = sqlite3.connect('/mnt/witf_lambda_efs/rcps_sims_chunks.db')
    rcp_sims_c = rcp_sims_db.cursor()
    
    rcp_counts = 31521
    print('## RCP COUNTS', rcp_counts)
    print('## Recom Hist', recom_hist)
    print()
    recoms = []
    if len(liked_recoms) == 0:
        recoms += random.sample(list(set(range(rcp_counts)) - set(recom_hist)), n)
    else:
        children_per_recom = n // len(liked_recoms)
        children_per_recom = max(children_per_recom, 1)
    
        for rcp1_idx in liked_recoms:
            
            print('## Genrating {} recom'.format(rcp1_idx))
            
            rcp_sims_c.execute('''Select rcp2_idxs, sims from rcps_sims_{} where rcp1_idx={} Limit 1'''.format(rcp1_idx//1000, rcp1_idx))
            print('## Query successful from db')
    
            children_rcps_str, sims = rcp_sims_c.fetchone()
            
            print('## Fetch successful from db')
    
            rcp_sims = [(int(child_rcp), float(sim))
                        for child_rcp, sim in zip(children_rcps_str.split('|'), sims.split('|'))
                        if int(child_rcp) not in recom_hist][:children_per_recom]
            recoms += [children_rcp for children_rcp, _ in rcp_sims]
    
            # for rcp, sim in rcp_sims:
            #     print(id2rcp([rcp1_idx], return_info=False), '-{}->'.format(sim), id2rcp([rcp], return_info=False))
    
        deficit = n - len(recoms)
        if deficit > 0:
            supplements += random.sample(list(set(range(rcp_counts)) - set(recom_hist + recoms)), deficit)
            recoms += supplements

    rcp_sims_db.close()
    
    print('## Finished Task')
    print('## Recoms', recoms)
    
    ret_dict = {
        'statusCode': 200,
        'body': 'None',
        'recom_ids': recoms
    }
    
    for k, v in id2rcp(recoms).items():
        ret_dict[k] = v
    
    return ret_dict