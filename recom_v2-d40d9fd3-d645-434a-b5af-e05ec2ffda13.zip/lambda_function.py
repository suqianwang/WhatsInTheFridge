import json
import requests
import sqlite3
import random
import datetime
import os


def lambda_handler(event, context):
    # TODO implement
    
    
    print("here!")
    print("step 1", datetime.datetime.now())
    liked_recoms = event.get('liked_recoms')
    user_id = event.get('user_id')
    n = event.get('recom_amount')
    
    user_recom_hist = sqlite3.connect('/mnt/test_access_0_efs/user_recom_hist.db')
    c_hist = user_recom_hist.cursor()
    c_hist.execute('''Create TABLE if not exists recom_hist("user_id", "rcp_idx")''')
    c_hist.execute('''Select rcp_idx from recom_hist where user_id={}'''.format(user_id))
    recom_hist = [rcp_idx[0] for rcp_idx in c_hist.fetchall()]
    
    apiFTKey = "wroXiS8dSq4aO0HBiXyKX4bZjaHakhcI8x8SfJ7g"
    headers = {'X-API-Key':apiFTKey}
    apiFTUrl = "https://jegp1jgq2h.execute-api.us-east-1.amazonaws.com/default/witf_recom"
    payloadFT = json.dumps({
        "recom_hist": recom_hist,
        "liked_recoms": liked_recoms,
        "user_id": user_id,
        "recom_amount": n,
    })
    header={"x-api-key" : apiFTKey}
    print("step 2", datetime.datetime.now())
    responseFT = requests.get(apiFTUrl, data=payloadFT, headers=header)
    print("FIINISHED LAMBDA CALL")
    print("text", responseFT.text)
    
    
    # str1 = ''
    # for k, v in responseFT.json().items():
    #     str1 += '{}, '.format(k)
    
    recoms = responseFT.json()['recom_ids']
    for recom in recoms:
        c_hist.execute(
            'Insert into recom_hist (user_id, rcp_idx) values (?,?)',
            (user_id, int(recom))
        )


    user_recom_hist.commit()
    user_recom_hist.close()

    # return {
    #     'statusCode': 200,
    #     # 'body': json.dumps(responseFT.json()["body"])
    #     'body': str1
    # }
    
    return responseFT.json()
